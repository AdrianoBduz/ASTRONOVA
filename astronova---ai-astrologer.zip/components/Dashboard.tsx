import React from 'react';
import { FullAnalysisData } from '../types';
import { SparklesIcon } from './Icons';

interface DashboardProps {
    data: FullAnalysisData;
    onQuestionSelect: (question: string) => void;
    profileName?: string;
}

const ElementalBar = ({ label, value, color }: { label: string, value: number, color: string }) => (
    <div className="mb-5 group">
        <div className="flex justify-between text-[10px] uppercase tracking-[0.2em] font-bold text-slate-400 mb-2 group-hover:text-white transition-colors">
            <span>{label}</span>
            <span>{value}%</span>
        </div>
        <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
            <div 
                className={`h-full ${color} transition-all duration-1000 ease-out shadow-[0_0_15px_currentColor] relative`} 
                style={{ width: `${value}%` }}
            >
                <div className="absolute inset-0 bg-white/30 animate-[shine_2s_infinite_linear]"></div>
            </div>
        </div>
    </div>
);

const Dashboard: React.FC<DashboardProps> = ({ data, onQuestionSelect, profileName }) => {
    return (
        <div className="space-y-12 text-slate-200 pb-24">
            
            {/* 1. HERO SECTION - Stagger 0ms */}
            <div className="opacity-0 animate-slide-up relative rounded-[2.5rem] p-8 md:p-14 overflow-hidden border border-white/10 shadow-2xl group transition-all duration-700 hover:border-indigo-500/30">
                 {/* Dynamic Background */}
                 <div className="absolute inset-0 bg-[#08090E]"></div>
                 <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-indigo-600/20 rounded-full blur-[150px] mix-blend-screen opacity-60 animate-pulse-slow"></div>
                 <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-cyan-600/10 rounded-full blur-[120px] mix-blend-screen opacity-50 animate-float"></div>
                 
                 <div className="relative z-10">
                    <div className="flex flex-col md:flex-row justify-between items-start gap-10 mb-10">
                        <div className="flex-1">
                            {/* Personalization Tag */}
                            <div className="flex flex-col gap-2 mb-6">
                                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-indigo-500/30 bg-indigo-500/10 backdrop-blur-md text-indigo-300 text-[10px] uppercase tracking-[0.25em] font-bold shadow-[0_0_20px_rgba(99,102,241,0.2)] w-fit">
                                    <SparklesIcon className="w-3 h-3" /> Relatório Mestre
                                </div>
                                {profileName && (
                                    <div className="text-xl font-display font-light text-slate-400 tracking-widest uppercase">
                                        Preparado para <span className="text-white font-bold border-b border-indigo-500/50 pb-1">{profileName}</span>
                                    </div>
                                )}
                            </div>

                            <h2 className="text-5xl md:text-7xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-white via-indigo-100 to-slate-400 mb-6 tracking-tight leading-tight drop-shadow-lg">
                                {data.resumo_geral.arquetipo_principal}
                            </h2>
                            <p className="text-2xl text-indigo-200/90 font-serif italic max-w-3xl leading-relaxed border-l-2 border-indigo-500/50 pl-6">
                                "{data.resumo_geral.frase_poder}"
                            </p>
                        </div>
                        
                        <div className="flex flex-col gap-4 min-w-[220px]">
                            <InfoBadge label="Cristal Mestre" value={data.insights_praticos.cristal_poder} color="text-cyan-300" glow="shadow-cyan-500/20" />
                            <InfoBadge label="Cor de Poder" value={data.insights_praticos.cor_favoravel} color="text-purple-300" glow="shadow-purple-500/20" />
                        </div>
                    </div>

                    <div className="glass-panel rounded-2xl p-8 border border-white/5 bg-black/20">
                        <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-4">Análise da Essência</h4>
                        <p className="text-slate-300 leading-9 font-light whitespace-pre-wrap text-lg">
                            {data.resumo_geral.introducao_longa}
                        </p>
                    </div>
                 </div>
            </div>

            {/* 2. THE BIG THREE - Stagger 200ms */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Left Column: Detailed Planets */}
                <div className="lg:col-span-8 space-y-8">
                    <div className="opacity-0 animate-slide-up delay-100">
                        <SectionTitle title="A Tríade Primária" subtitle="Os pilares fundamentais da sua existência" />
                    </div>
                    
                    <div className="opacity-0 animate-slide-up delay-200">
                        <DetailedPlanetCard 
                            title="SOL" 
                            sign={data.mapa_astral.sol.signo}
                            detail={`Casa ${data.mapa_astral.sol.casa} • ${data.mapa_astral.sol.grau}`}
                            content={data.mapa_astral.sol.interpretacao}
                            icon="☉"
                            theme="amber"
                        />
                    </div>
                    
                    <div className="opacity-0 animate-slide-up delay-300">
                        <DetailedPlanetCard 
                            title="LUA" 
                            sign={data.mapa_astral.lua.signo}
                            detail={`Casa ${data.mapa_astral.lua.casa} • Fase ${data.mapa_astral.lua.fase}`}
                            content={data.mapa_astral.lua.interpretacao}
                            icon="☽"
                            theme="blue"
                        />
                    </div>
                    
                    <div className="opacity-0 animate-slide-up delay-400">
                        <DetailedPlanetCard 
                            title="ASCENDENTE" 
                            sign={data.mapa_astral.ascendente.signo}
                            detail="Casa 1 • A Máscara Social"
                            content={data.mapa_astral.ascendente.interpretacao}
                            icon="↑"
                            theme="emerald"
                        />
                    </div>

                    <div className="opacity-0 animate-slide-up delay-500 mt-16">
                        <SectionTitle title="Eixos de Destino" subtitle="Relacionamentos e Propósito" />
                    </div>

                    <div className="opacity-0 animate-slide-up delay-500">
                        <DetailedPlanetCard 
                            title="DESCENDENTE" 
                            sign={data.mapa_astral.descendente.signo}
                            detail="Casa 7 • O Outro"
                            content={data.mapa_astral.descendente.interpretacao}
                            icon="↓"
                            theme="rose"
                        />
                    </div>

                    <div className="opacity-0 animate-slide-up delay-700">
                        <DetailedPlanetCard 
                            title="MEIO DO CÉU" 
                            sign={data.mapa_astral.meio_do_ceu.signo}
                            detail="Casa 10 • O Legado"
                            content={data.mapa_astral.meio_do_ceu.interpretacao}
                            icon="MC"
                            theme="violet"
                        />
                    </div>
                </div>

                {/* Right Column: Elements, Numerology - Sticky */}
                <div className="lg:col-span-4 space-y-8 opacity-0 animate-slide-up delay-300">
                    
                    {/* Elemental Chart */}
                    <div className="glass-card rounded-3xl p-8 sticky top-6 overflow-hidden">
                        <div className="absolute top-0 right-0 p-10 bg-indigo-500/10 blur-[50px] rounded-full pointer-events-none"></div>
                        <h3 className="text-xs uppercase tracking-[0.2em] text-white font-bold mb-8 flex items-center gap-3">
                            <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full shadow-[0_0_10px_currentColor]"></span>
                            Constituição Elemental
                        </h3>
                        <ElementalBar label="Fogo" value={data.balanco_elemental.fogo} color="bg-gradient-to-r from-red-500 to-orange-500" />
                        <ElementalBar label="Terra" value={data.balanco_elemental.terra} color="bg-gradient-to-r from-emerald-500 to-green-400" />
                        <ElementalBar label="Ar" value={data.balanco_elemental.ar} color="bg-gradient-to-r from-yellow-400 to-amber-200" />
                        <ElementalBar label="Água" value={data.balanco_elemental.agua} color="bg-gradient-to-r from-blue-500 to-cyan-400" />
                        
                        <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
                            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Dominante</span>
                            <span className="text-xl font-display font-bold text-white tracking-wide">{data.balanco_elemental.elemento_dominante}</span>
                        </div>
                    </div>

                    {/* Numerology Deep Dive */}
                    <div className="glass-card rounded-3xl p-8 relative overflow-hidden group">
                        <div className="absolute -right-10 -top-10 text-[150px] font-display font-bold text-white/5 group-hover:text-white/10 transition-colors duration-500 select-none">
                            {data.numerologia.numero_destino}
                        </div>
                        <h3 className="text-xs uppercase tracking-[0.2em] text-white font-bold mb-2 relative z-10">Numerologia Pitagórica</h3>
                        <p className="text-[10px] text-slate-500 mb-6 uppercase tracking-wider font-medium relative z-10">Baseada no nome: <span className="text-indigo-400">{profileName}</span></p>
                        
                        <div className="flex gap-4 mb-8 relative z-10">
                             <div className="flex-1 bg-black/40 p-5 rounded-2xl border border-white/5 text-center backdrop-blur-sm transition-transform hover:-translate-y-1 duration-300">
                                <div className="text-4xl font-display font-bold text-indigo-400 mb-2 drop-shadow-[0_0_15px_rgba(99,102,241,0.5)]">{data.numerologia.numero_destino}</div>
                                <div className="text-[9px] text-slate-400 uppercase tracking-[0.2em] font-bold">Destino</div>
                             </div>
                             <div className="flex-1 bg-black/40 p-5 rounded-2xl border border-white/5 text-center backdrop-blur-sm transition-transform hover:-translate-y-1 duration-300">
                                <div className="text-4xl font-display font-bold text-purple-400 mb-2 drop-shadow-[0_0_15px_rgba(168,85,247,0.5)]">{data.numerologia.numero_alma}</div>
                                <div className="text-[9px] text-slate-400 uppercase tracking-[0.2em] font-bold">Alma</div>
                             </div>
                        </div>
                        <p className="text-sm text-slate-300 leading-7 font-light text-justify relative z-10 border-t border-white/5 pt-6">
                            {data.numerologia.interpretacao_completa}
                        </p>
                    </div>

                    {/* Mission Card */}
                    <div className="p-8 rounded-3xl bg-gradient-to-br from-indigo-900/10 to-transparent border border-indigo-500/20 backdrop-blur-md">
                        <h3 className="text-indigo-300 font-bold uppercase tracking-[0.2em] text-xs mb-4">Missão de Alma</h3>
                        <p className="text-slate-200 leading-relaxed italic font-serif text-lg">
                            "{data.insights_praticos.missao_alma}"
                        </p>
                    </div>

                </div>
            </div>

            {/* 3. PLANETARY DYNAMICS - Stagger 1000ms */}
            <div className="opacity-0 animate-slide-up delay-700 mt-16">
                 <SectionTitle title="Dinâmica Planetária" subtitle="Análise detalhada das forças internas" />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 opacity-0 animate-slide-up delay-1000">
                 {/* Personal Planets */}
                 <DetailedBlock title="Mercúrio" subtitle="Intelecto & Comunicação" content={data.mapa_astral.planetas_pessoais.mercurio} />
                 <DetailedBlock title="Vênus" subtitle="Amor & Valores" content={data.mapa_astral.planetas_pessoais.venus} />
                 <DetailedBlock title="Marte" subtitle="Ação & Desejo" content={data.mapa_astral.planetas_pessoais.marte} />
                 
                 {/* Social Planets */}
                 <DetailedBlock title="Júpiter" subtitle="Expansão & Sabedoria" content={data.mapa_astral.planetas_sociais.jupiter} />
                 <DetailedBlock title="Saturno" subtitle="Karma & Estrutura" content={data.mapa_astral.planetas_sociais.saturno} />
                 
                 {/* Transpersonal */}
                 <DetailedBlock title="Urano" subtitle="Inovação & Caos" content={data.mapa_astral.planetas_transpessoais.urano} />
                 <DetailedBlock title="Netuno" subtitle="Sonhos & Ilusão" content={data.mapa_astral.planetas_transpessoais.netuno} />
                 <DetailedBlock title="Plutão" subtitle="Poder & Transformação" content={data.mapa_astral.planetas_transpessoais.plutao} />
            </div>

             {/* 4. CURRENT CHALLENGE */}
             <div className="opacity-0 animate-slide-up delay-1000 mt-12 bg-gradient-to-r from-red-950/20 to-black border border-red-900/30 rounded-3xl p-10 relative overflow-hidden group hover:border-red-500/30 transition-colors duration-500">
                <div className="absolute top-0 right-0 w-96 h-96 bg-red-600/5 rounded-full blur-[100px] group-hover:bg-red-600/10 transition-colors duration-700"></div>
                <h3 className="text-red-400 font-bold uppercase tracking-[0.25em] text-xs mb-6 relative z-10 flex items-center gap-3">
                    <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></span>
                    Desafio Evolutivo Atual
                </h3>
                <p className="text-slate-300 leading-9 font-light text-lg relative z-10 max-w-5xl">
                    {data.insights_praticos.desafio_atual}
                </p>
             </div>

            {/* Footer / Chat Prompts */}
            <div className="opacity-0 animate-slide-up delay-1000 pt-16 border-t border-white/5 text-center">
                <h3 className="text-xs text-slate-500 uppercase tracking-[0.25em] mb-8 font-bold">Continuar Jornada</h3>
                <div className="flex flex-wrap justify-center gap-4">
                    {data.interacao_ia_chat.sugestoes_avancadas.map((q, i) => (
                        <button 
                            key={i}
                            onClick={() => onQuestionSelect(q)}
                            className="group relative px-8 py-4 bg-white/5 border border-white/10 hover:border-indigo-500/50 text-slate-300 hover:text-white rounded-2xl text-sm font-medium transition-all duration-300 overflow-hidden"
                        >
                            <div className="absolute inset-0 bg-indigo-500/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                            <span className="relative z-10">{q}</span>
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

// UI Components for the Dashboard

const SectionTitle = ({ title, subtitle }: { title: string, subtitle: string }) => (
    <div className="mb-8 pl-6 border-l-2 border-indigo-500/50">
        <h3 className="text-3xl font-display font-bold text-white tracking-wide mb-2">{title}</h3>
        <p className="text-indigo-300/60 text-sm uppercase tracking-[0.15em] font-medium">{subtitle}</p>
    </div>
);

const InfoBadge = ({ label, value, color, glow }: any) => (
    <div className={`glass-panel p-5 rounded-2xl shadow-lg hover:bg-white/5 transition-colors duration-300`}>
        <div className="text-[9px] text-slate-500 uppercase tracking-[0.2em] font-bold mb-2">{label}</div>
        <div className={`text-lg font-bold font-display ${color} drop-shadow-[0_0_10px_rgba(255,255,255,0.2)]`}>{value}</div>
    </div>
);

const DetailedPlanetCard = ({ title, sign, detail, content, icon, theme }: any) => {
    const colors: any = {
        amber: 'from-amber-500/10 to-transparent border-amber-500/20 text-amber-400 group-hover:border-amber-500/40',
        blue: 'from-blue-500/10 to-transparent border-blue-500/20 text-blue-400 group-hover:border-blue-500/40',
        emerald: 'from-emerald-500/10 to-transparent border-emerald-500/20 text-emerald-400 group-hover:border-emerald-500/40',
        rose: 'from-rose-500/10 to-transparent border-rose-500/20 text-rose-400 group-hover:border-rose-500/40',
        violet: 'from-violet-500/10 to-transparent border-violet-500/20 text-violet-400 group-hover:border-violet-500/40',
    };
    const activeTheme = colors[theme] || colors.blue;

    return (
        <div className={`group relative rounded-3xl bg-[#0A0B10] border ${activeTheme.split(' ')[2]} ${activeTheme.split(' ')[4]} overflow-hidden transition-all duration-500 hover:shadow-2xl hover:-translate-y-1`}>
            {/* Ambient Background */}
            <div className={`absolute inset-0 bg-gradient-to-r ${activeTheme.split(' ')[0]} opacity-30 group-hover:opacity-50 transition-opacity duration-700`}></div>
            <div className="absolute -right-20 -top-20 w-64 h-64 bg-white/5 rounded-full blur-[80px] pointer-events-none group-hover:bg-white/10 transition-colors"></div>
            
            <div className="relative z-10 p-8 md:p-10">
                <div className="flex justify-between items-start mb-8">
                    <div>
                        <div className={`text-[10px] uppercase tracking-[0.25em] font-bold mb-3 opacity-80 ${activeTheme.split(' ')[3]}`}>{title}</div>
                        <div className="text-4xl font-display font-bold text-white flex items-center gap-4 mb-2">
                            {sign}
                        </div>
                        <div className="text-sm text-slate-400 font-mono tracking-wide opacity-60 bg-black/40 inline-block px-3 py-1 rounded-md">{detail}</div>
                    </div>
                    <div className="text-6xl text-white/5 font-serif group-hover:text-white/10 transition-colors duration-500 transform group-hover:scale-110 origin-top-right">{icon}</div>
                </div>
                
                <div className="prose prose-invert prose-lg max-w-none border-t border-white/5 pt-6">
                    <p className="text-slate-300 leading-8 font-light whitespace-pre-wrap text-justify opacity-90 group-hover:opacity-100 transition-opacity">
                        {content}
                    </p>
                </div>
            </div>
        </div>
    );
};

const DetailedBlock = ({ title, subtitle, content }: any) => (
    <div className="glass-card rounded-3xl p-8 hover:bg-white/5 hover:border-white/20 transition-all duration-300 group">
        <div className="mb-6 pb-4 border-b border-white/5 group-hover:border-white/10 transition-colors">
            <h4 className="text-xl font-bold text-white font-display mb-1">{title}</h4>
            <span className="text-[10px] text-indigo-300/70 uppercase tracking-[0.2em] font-bold">{subtitle}</span>
        </div>
        <p className="text-sm text-slate-300 leading-7 font-light whitespace-pre-wrap text-justify opacity-80 group-hover:opacity-100 transition-opacity">
            {content}
        </p>
    </div>
);

export default Dashboard;