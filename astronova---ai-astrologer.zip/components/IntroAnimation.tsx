import React, { useEffect, useState } from 'react';

const SYSTEM_LOGS = [
    "Carregando Efemérides da NASA (JPL)...",
    "Sincronizando Coordenadas Geocêntricas...",
    "Calculando Vetores de Casas Placidus...",
    "Analisando Aspectos Planetários Maiores...",
    "Detectando Padrões Kármicos...",
    "Processando Arquétipos Junguianos...",
    "Sintetizando Tríade Primária (Sol/Lua/Asc)...",
    "Verificando Intercepções Zodiacais...",
    "Acessando Registros Akáshicos...",
    "Compilando Relatório Mestre...",
    "Finalizando Renderização Neural..."
];

const IntroAnimation: React.FC<{ onComplete?: () => void }> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [currentLog, setCurrentLog] = useState(SYSTEM_LOGS[0]);
  const [logsHistory, setLogsHistory] = useState<string[]>([]);
  const [isExiting, setIsExiting] = useState(false);
  
  useEffect(() => {
    const duration = 10000; // 10 seconds total load
    const intervalTime = 50; 
    
    let currentTime = 0;
    let logIndex = 0;
    
    const progressInterval = setInterval(() => {
        currentTime += intervalTime;
        const rawProgress = (currentTime / duration) * 100;
        const newProgress = Math.min(rawProgress, 99); 
        
        setProgress(newProgress);
        
        // Update logs based on progress milestones
        const calculatedLogIndex = Math.floor((currentTime / duration) * SYSTEM_LOGS.length);
        if (calculatedLogIndex !== logIndex && calculatedLogIndex < SYSTEM_LOGS.length) {
            logIndex = calculatedLogIndex;
            const newLog = SYSTEM_LOGS[logIndex];
            setCurrentLog(newLog);
            setLogsHistory(prev => [...prev.slice(-4), newLog]); // Keep last 5 lines
        }

    }, intervalTime);

    return () => clearInterval(progressInterval);
  }, []);

  useEffect(() => {
     if (isExiting && onComplete) {
         const timer = setTimeout(onComplete, 800);
         return () => clearTimeout(timer);
     }
  }, [isExiting, onComplete]);

  return (
    <div className={`fixed inset-0 z-[100] bg-[#020204] flex flex-col items-center justify-center overflow-hidden font-display transition-all duration-1000 ease-[cubic-bezier(0.22,1,0.36,1)] ${isExiting ? 'opacity-0 scale-105 filter blur-lg' : 'opacity-100 scale-100'}`}>
      
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-900/20 via-[#020204] to-[#020204]"></div>
      <div className="absolute inset-0 opacity-20 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] brightness-100 contrast-150"></div>
      
      {/* Main Content Container */}
      <div className="relative z-10 flex flex-col items-center w-full max-w-2xl px-6">
        
        {/* Holographic Astrolabe Loader */}
        <div className="relative w-64 h-64 md:w-80 md:h-80 mb-12 flex items-center justify-center">
            {/* Base Glow */}
            <div className="absolute inset-0 bg-indigo-500/5 blur-[60px] rounded-full animate-pulse-slow"></div>

            {/* Ring 1 - Outer Static */}
            <div className="absolute inset-0 border border-white/5 rounded-full"></div>
            
            {/* Ring 2 - Slow Rotate */}
            <div className="absolute inset-4 border border-indigo-500/20 rounded-full border-t-transparent border-l-transparent animate-[spin_10s_linear_infinite]"></div>
            
            {/* Ring 3 - Counter Rotate Fast */}
            <div className="absolute inset-8 border border-cyan-500/30 rounded-full border-b-transparent border-r-transparent animate-[spin_3s_linear_infinite_reverse] shadow-[0_0_15px_rgba(6,182,212,0.1)]"></div>

            {/* Ring 4 - Geometric Decor */}
            <svg className="absolute inset-0 w-full h-full animate-[spin_20s_linear_infinite] opacity-30" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="48" fill="none" stroke="currentColor" strokeWidth="0.2" className="text-white" strokeDasharray="4 4" />
                <path d="M50 2 L50 98 M2 50 L98 50" stroke="currentColor" strokeWidth="0.2" className="text-indigo-500" />
                <rect x="29" y="29" width="42" height="42" fill="none" stroke="currentColor" strokeWidth="0.2" className="text-purple-500" transform="rotate(45 50 50)" />
            </svg>

            {/* Center Core */}
            <div className="relative z-10 w-24 h-24 bg-black/80 backdrop-blur-xl rounded-full border border-indigo-500/30 flex items-center justify-center shadow-[0_0_30px_rgba(99,102,241,0.3)]">
                <div className="text-2xl font-bold text-white animate-pulse">{Math.floor(progress)}%</div>
                
                {/* Orbital Dot */}
                <div className="absolute inset-0 animate-[spin_2s_linear_infinite]">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 w-2 h-2 bg-cyan-400 rounded-full shadow-[0_0_10px_rgba(6,182,212,1)]"></div>
                </div>
            </div>
        </div>

        {/* Text & Status */}
        <div className="w-full text-center space-y-6">
            <h2 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-white via-indigo-200 to-slate-400 tracking-[0.2em] drop-shadow-xl">
                ASTRONOVA
            </h2>
            
            {/* Progress Bar */}
            <div className="relative w-full h-1 bg-white/5 rounded-full overflow-hidden">
                <div 
                    className="absolute inset-y-0 left-0 bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-600 shadow-[0_0_20px_rgba(99,102,241,0.5)] transition-all duration-200 ease-out"
                    style={{ width: `${progress}%` }}
                >
                    <div className="absolute inset-0 bg-white/30 animate-[shine_1s_infinite_linear]"></div>
                </div>
            </div>

            {/* System Log Terminal */}
            <div className="h-24 w-full flex flex-col justify-end items-center overflow-hidden relative">
                <div className="absolute inset-0 bg-gradient-to-t from-[#020204] via-transparent to-transparent z-10"></div>
                {logsHistory.map((log, i) => (
                    <div key={i} className={`text-[10px] md:text-xs font-mono tracking-wider transition-all duration-300 ${i === logsHistory.length - 1 ? 'text-cyan-400 opacity-100 scale-105 font-bold' : 'text-slate-600 opacity-40'}`}>
                        {`> ${log}`}
                    </div>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default IntroAnimation;