import React from 'react';
import { MoonData } from '../types';

interface MoonWidgetProps {
  data: MoonData;
}

const ZODIAC_SIGNS = [
  "♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓"
];

const MoonWidget: React.FC<MoonWidgetProps> = ({ data }) => {
  // Calculate rotation: Each sign is 30 degrees. 
  // We center the content, so we want the active sign at the top or clearly marked.
  // Let's rotate the 'moon' cursor to the correct angle.
  // 0 deg = top (Aries) typically in charts, or Left. Let's assume standard wheel: Aries at 9 o'clock or 0 degrees.
  // Let's standard: 0 = Aries at top.
  const angle = data.zodiacIndex * 30 + 15; // Center of the sign sector

  return (
    <div className="bg-astro-panel/50 border border-white/10 rounded-2xl p-6 relative overflow-hidden backdrop-blur-md flex flex-col items-center animate-float">
      <div className="absolute inset-0 bg-gradient-to-b from-indigo-900/20 to-transparent pointer-events-none" />
      
      <h3 className="text-lg font-display font-bold text-white mb-4 z-10 flex items-center gap-2">
        <span className="text-cyan-400">●</span> Sua Lua
      </h3>

      {/* Chart Visualization */}
      <div className="relative w-48 h-48 mb-6 z-10">
        {/* Outer Ring */}
        <div className="absolute inset-0 rounded-full border-2 border-white/5 border-dashed animate-[spin_60s_linear_infinite]" />
        
        {/* Zodiac Ring */}
        <div className="absolute inset-2 rounded-full border border-white/10">
            {ZODIAC_SIGNS.map((sign, i) => {
                const rotation = i * 30;
                // Position numbers around the circle
                const rad = (rotation - 90) * (Math.PI / 180);
                const x = 50 + 40 * Math.cos(rad); // 50% center, 40% radius
                const y = 50 + 40 * Math.sin(rad);
                
                return (
                    <div 
                        key={i}
                        className={`absolute w-6 h-6 flex items-center justify-center text-sm font-bold transform -translate-x-1/2 -translate-y-1/2 transition-colors duration-500
                            ${i === data.zodiacIndex ? 'text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.8)] scale-125' : 'text-slate-600'}`}
                        style={{ left: `${x}%`, top: `${y}%` }}
                    >
                        {sign}
                    </div>
                );
            })}
        </div>

        {/* Inner Hub */}
        <div className="absolute inset-[25%] rounded-full bg-astro-dark border border-white/10 flex items-center justify-center shadow-inner">
            <div className="text-center">
                <div className="text-xs text-slate-400 uppercase tracking-wider">Signo</div>
                <div className="font-display font-bold text-lg text-white">{data.sign}</div>
            </div>
        </div>

        {/* The Moon Indicator */}
        <div 
            className="absolute top-0 left-0 w-full h-full pointer-events-none transition-transform duration-1000 ease-out"
            style={{ transform: `rotate(${angle}deg)` }}
        >
             {/* The Arm */}
            <div className="absolute top-0 left-1/2 h-1/2 w-[1px] bg-gradient-to-b from-cyan-400/50 to-transparent origin-bottom -translate-x-1/2" />
            
            {/* The Planet Icon */}
            <div className="absolute top-[10%] left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div className="w-4 h-4 bg-cyan-100 rounded-full shadow-[0_0_15px_rgba(6,182,212,1)]" />
            </div>
        </div>
      </div>

      <div className="text-center z-10">
        <div className="inline-block px-3 py-1 bg-white/5 rounded-full text-xs text-cyan-300 mb-2 border border-white/5">
            Fase: {data.phase}
        </div>
        <p className="text-sm text-slate-300 leading-relaxed italic">
          "{data.description}"
        </p>
      </div>
    </div>
  );
};

export default MoonWidget;