import React from 'react';

const StarBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[-1] overflow-hidden pointer-events-none">
      {/* Deep Space Background */}
      <div className="absolute inset-0 bg-astro-dark"></div>
      
      {/* Nebula Gradients */}
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-900/20 via-astro-dark to-astro-dark opacity-70"></div>
      <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-purple-900/20 via-astro-dark to-astro-dark opacity-60"></div>

      {/* Stars - Simulated with small divs for performance instead of heavy canvas */}
      <div className="absolute inset-0 opacity-50">
          {[...Array(50)].map((_, i) => (
              <div
                key={i}
                className="absolute bg-white rounded-full animate-pulse-slow"
                style={{
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                    width: `${Math.random() * 2 + 1}px`,
                    height: `${Math.random() * 2 + 1}px`,
                    animationDelay: `${Math.random() * 5}s`,
                    opacity: Math.random()
                }}
              />
          ))}
      </div>
    </div>
  );
};

export default StarBackground;